package allone.test.chat;

public interface A {

	public void method1();

	public void method2();

	public void method3();

	public void method4();
}
