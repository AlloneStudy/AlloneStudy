package allone.test.chat;

public class C extends BAdapter {

	@Override
	public void method2() {

	}
}
