package allone.test.chat;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class TestPane extends JPanel {

	private static final long serialVersionUID = -6785459112758033624L;

	private ChartPane chart1;
	private ChartPane chart2;
	private ChartPane chart3;
	private ChartPane chart4;

	private JButton btn1, btn2, btn3, btn4;

	private QuoteCaptain catapin;

	public TestPane() {
		catapin = new QuoteCaptain();
		initComponent();
		layoutComponent();
	}

	private void initComponent() {
		chart1 = new ChartPane("USD/CNY");
		chart2 = new ChartPane("USD/JPY");
		chart3 = new ChartPane("AUD/JPY");
		chart4 = new ChartPane("AUD/CHF");

		btn1 = new JButton("Send USD/CNY");
		btn1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				catapin.fireEventList("USD/CNY");
			}
		});
		btn2 = new JButton("Send USD/JPY");
		btn2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				catapin.fireEventList("USD/JPY");
			}
		});
		btn3 = new JButton("Send AUD/JPY");
		btn3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				catapin.fireEventList("AUD/JPY");
			}
		});
		btn4 = new JButton("Send AUD/CHF");
		btn4.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				catapin.fireEventList("AUD/CHF");
			}
		});
	}

	private void layoutComponent() {
		JPanel workspace = new JPanel(new GridLayout(2, 2));
		this.setLayout(new BorderLayout());
		workspace.add(chart1);
		workspace.add(chart2);
		workspace.add(chart3);
		workspace.add(chart4);
		this.add(workspace, BorderLayout.CENTER);
		JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 3));
		btnPanel.add(btn1);
		btnPanel.add(btn2);
		btnPanel.add(btn3);
		btnPanel.add(btn4);
		this.add(btnPanel, BorderLayout.SOUTH);
	}
}
