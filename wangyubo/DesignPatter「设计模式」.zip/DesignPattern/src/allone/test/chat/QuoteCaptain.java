package allone.test.chat;

import java.util.LinkedList;

import javax.swing.event.EventListenerList;

public class QuoteCaptain {

	public static LinkedList<IQuote> eventList = new LinkedList<IQuote>();

	public static void addEventList(IQuote quote) {
		eventList.add(quote);
	}

	public static void fireEventList(String inst) {
		for (IQuote quote : eventList) {
			quote.onDataChange(inst);
		}
	}
}
