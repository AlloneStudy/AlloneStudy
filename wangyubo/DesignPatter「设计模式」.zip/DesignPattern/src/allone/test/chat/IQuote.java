package allone.test.chat;

public interface IQuote {

	public void onDataChange(String inst);
}
