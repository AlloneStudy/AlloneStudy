package allone.test.chat;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ChartPane extends JPanel implements IQuote {

	private static final long serialVersionUID = 865265211786161722L;

	private JButton btn;
	private JLabel label;

	private String inst;

	public ChartPane(String inst) {
		this.inst = inst;
		initComponent();
		layoutComponent();
		QuoteCaptain.addEventList(this);
	}

	private void initComponent() {
		btn = new JButton("test");
		btn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(btn, inst);
			}
		});
		label = new JLabel(inst);
	}

	private void layoutComponent() {
		JPanel workspace = new JPanel();
		workspace.setBorder(BorderFactory.createLineBorder(Color.RED));
		workspace.setLayout(new BorderLayout());
		workspace.add(label, BorderLayout.NORTH);
		workspace.add(btn);
		this.add(workspace);
	}

	@Override
	public void onDataChange(String _inst) {
		if (_inst.equals(inst)) {
			label.setText(inst + " 2 ");
		}
	}
}
