package allone.test.factory3_;

public interface Sourceable {
	public void method1();

	public void method2();
}
