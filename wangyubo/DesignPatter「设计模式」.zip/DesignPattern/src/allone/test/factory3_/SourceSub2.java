package allone.test.factory3_;

public class SourceSub2 extends Wrapper2 {
	public void method2() {
		System.out.println("the sourceable interface's first Sub2!");
	}
}
