package allone.test.factory3_;

public abstract class Wrapper2 implements Sourceable {

	@Override
	public void method1() {
	}

	@Override
	public void method2() {
	}

}
