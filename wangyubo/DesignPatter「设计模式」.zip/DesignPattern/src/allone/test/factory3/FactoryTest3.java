package allone.test.factory3;

/**
 * ������ģʽ
 * 
 * @author wangyubo
 * 
 */
public class FactoryTest3 {
	
	public static void main(String[] args) {
		Targetable target = new Adapter();
		target.method1();
		target.method2();
	}
	
}
