package allone.test.factory3;

public class Source {
	
	public void method1() {
		System.out.println("this is original method!");
	}
	
}
