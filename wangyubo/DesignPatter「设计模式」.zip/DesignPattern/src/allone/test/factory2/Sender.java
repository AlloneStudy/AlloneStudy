package allone.test.factory2;

public interface Sender {
	public void Send();
}
