package allone.test.factory2;

public interface Provider {
	public Sender produce();
}
