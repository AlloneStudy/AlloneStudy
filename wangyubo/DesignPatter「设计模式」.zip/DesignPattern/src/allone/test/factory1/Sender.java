package allone.test.factory1;

public interface Sender {
	public void Send();
}
