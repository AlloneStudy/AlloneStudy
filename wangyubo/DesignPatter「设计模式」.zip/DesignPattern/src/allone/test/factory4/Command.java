package allone.test.factory4;

public interface Command {
	public void exe();
}
