package allone.test.factory4;

public class Receiver {
	public void action() {
		System.out.println("command received!");
	}
}
